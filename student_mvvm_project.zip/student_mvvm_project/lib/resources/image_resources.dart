class ImageResources{
  static const logowithname = "assets/images/GoLocal_LOGO-1.png";
  static const logo = "assets/images/logo_new.png";
  static const search = "assets/images/loupe.png";
  static const profile = "assets/images/profile-user.png";
  static const banner02 = "assets/images/no-image.jpg";
  static const noimagecover = "assets/images/no-image-1.jpg";
  static const intro01 = "assets/images/intro1.jpg";
  static const intro02 = "assets/images/intro2.jpg";
  static const intro03 = "assets/images/intro3.jpg";
  static const intro04 = "assets/images/intro4.jpg";
  static const intro05 = "assets/images/intro5.jpg";
  static const intro06 = "assets/images/intro6.jpg";
}