package com.dipen.student_mvvm_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
